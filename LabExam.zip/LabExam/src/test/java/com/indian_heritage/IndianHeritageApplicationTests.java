package com.indian_heritage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndianHeritageApplicationTests {

	@Test
	void contextLoads() {
	}

}
